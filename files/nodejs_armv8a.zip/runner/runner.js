#!/usr/bin/env node

/**
 * Node.js Runner 入口脚本
 * 用于加载并执行用户的爬虫脚本
 * 
 * 使用方式: node runner.js <爬虫脚本路径> <方法名> <argsJson>
 * 示例: node runner.js ./甜圈短剧.js homeContent '{"filter":true}'
 */

const fs = require('fs');
const path = require('path');

// ==================== 错误处理配置 ====================

process.on('uncaughtException', (error) => {
    console.error(JSON.stringify({ error: `Uncaught Exception: ${error.message}` }));
    process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error(JSON.stringify({ error: `Unhandled Rejection: ${reason}` }));
    process.exit(1);
});

// ==================== 参数解析 ====================

if (process.argv.length < 5) {
    console.log(JSON.stringify({ error: 'Usage: node runner.js <spider> <method> <argsJson>' }));
    process.exit(1);
}

const spiderFile = process.argv[2];   // 爬虫脚本路径，例如 "./甜圈短剧.js"
const method = process.argv[3];       // 方法名，例如 "homeContent"
let argsJson = process.argv[4];       // JSON 参数

// 优先尝试直接解析
let params = {};
try {
    params = JSON.parse(argsJson);
} catch (error) {
    // 如果解析失败，再尝试规范化（处理不带引号的JSON）
    try {
        // 规范化键：为花括号或逗号后面的单词加引号
        let normalized = argsJson.replace(/([{,])\s*([a-zA-Z0-9_]+)\s*:/g, '$1"$2":');
        // 规范化值：为冒号后面紧跟的单词（前面没有引号）加引号
        normalized = normalized.replace(/:\s*([^\s"{,}\d\[\]][^,}]*)/g, ':"$1"');
        params = JSON.parse(normalized);
    } catch (e) {
        params = {};
    }
}

// ==================== 加载爬虫脚本 ====================

if (!fs.existsSync(spiderFile)) {
    console.log(JSON.stringify({ error: `Spider not found: ${spiderFile}` }));
    process.exit(1);
}

// ==================== 处理模块加载路径 ====================

const runnerDir = __dirname;
const spiderBasePath = path.join(runnerDir, 'spider.js');

if (!fs.existsSync(spiderBasePath)) {
    console.log(JSON.stringify({ error: `Spider base class not found: ${spiderBasePath}` }));
    process.exit(1);
}

// 加载 Node.js 内部模块，用于修改 require 路径
const Module = require('module');
const originalLoad = Module._load;

/**
 * 覆盖 Module._load，使爬虫脚本能找到 spider.js 基类
 * 当爬虫脚本 require('./spider.js') 或 require('spider.js') 时，
 * 直接从 runner 目录加载
 */
Module._load = function(request, parent, isMain) {
    // 如果是加载 spider.js 相关模块，从 runner 目录加载
    if (request === './spider.js' || request === 'spider.js') {
        return originalLoad(spiderBasePath, parent, false);
    }
    return originalLoad.apply(this, arguments);
};


// ==================== 异步执行主逻辑 ====================

async function main() {
    try {
        // 先加载基类
        const { Spider: BaseSpider } = require(spiderBasePath);
        
        // 在全局作用域中注入 BaseSpider，这样爬虫脚本可以直接使用
        global.BaseSpider = BaseSpider;
        
        // 加载具体的爬虫脚本
        // 爬虫脚本会通过被覆盖的 Module._load 加载 spider.js
        const spiderModule = require(path.resolve(spiderFile));
        
        // 获取 Spider 类（可能是默认导出或命名导出）
        let SpiderClass;
        if (spiderModule.default && spiderModule.default.prototype instanceof BaseSpider) {
            SpiderClass = spiderModule.default;
        } else if (spiderModule.Spider && spiderModule.Spider.prototype instanceof BaseSpider) {
            SpiderClass = spiderModule.Spider;
        } else if (typeof spiderModule === 'function' && spiderModule.prototype instanceof BaseSpider) {
            SpiderClass = spiderModule;
        } else {
            // 尝试查找任何继承自BaseSpider的类
            for (const key in spiderModule) {
                if (spiderModule[key] && spiderModule[key].prototype instanceof BaseSpider) {
                    SpiderClass = spiderModule[key];
                    break;
                }
            }
        }
        
        if (!SpiderClass) {
            console.log(JSON.stringify({ error: 'Spider class not found in plugin' }));
            process.exit(2);
        }
        
        // 实例化爬虫
        const spider = new SpiderClass();
        
        // 调用方法：优先调用 Spider 实例的方法；如果实例没有该方法，尝试调用模块级函数
        const isInstanceMethod = typeof spider[method] === 'function';
        const isModuleFunc = typeof spiderModule[method] === 'function';
        
        if (!isInstanceMethod && !isModuleFunc) {
            console.log(JSON.stringify({ error: `Unknown method: ${method}` }));
            process.exit(3);
        }
        
        // 确定调用目标
        let func;
        
        if (isInstanceMethod) {
            func = spider[method].bind(spider);
        } else {
            func = spiderModule[method];
        }
        
        // 执行方法
        let result;
        try {
            // 将参数转换为数组，然后传递给函数
            let args;
            
            if (typeof params === 'object' && !Array.isArray(params)) {
                // 如果是对象，将其值转换为数组
                args = Object.values(params);
            } else if (Array.isArray(params)) {
                // 如果是数组，直接使用
                args = params;
            } else {
                // 其他情况，作为单个参数
                args = [params];
            }
            
            // 调用函数，传递参数数组
            result = await func(...args);
            
            if (typeof result === 'string') {
                console.log(result);
            } else {
                console.log(JSON.stringify(result));
            }
        } catch (execError) {
            console.log(JSON.stringify({ error: `Execution failed: ${execError.message}` }));
            process.exit(4);
        }
        
    } catch (loadError) {
        console.log(JSON.stringify({ error: `Load failed: ${loadError.message}` }));
        process.exit(5);
    }
}

// 执行主函数
main().catch(error => {
    console.log(JSON.stringify({ error: `Main execution failed: ${error.message}` }));
    process.exit(6);
});
