/**
 * Node.js Spider 基类和工具类
 * 
 * 包含：
 * - Spider: 爬虫基类，所有爬虫脚本应继承此类
 * - Result: 结果构建器，用于构建标准格式的返回结果
 * - Http: HTTP 请求工具类
 * - WebView: WebView 工具类
 */

const axios = require('axios');
const cheerio = require('cheerio');

// ==================== 爬虫基类 ====================

/**
 * 爬虫基类
 * 所有 Node.js 爬虫脚本应继承此类并实现相应方法
 */
class Spider {
    
    constructor() {
        this.siteKey = '';   // 站点标识
        this.siteType = 0;   // 站点类型
        this.extend = '';    // 扩展参数
    }
    
    /**
     * 初始化
     * @param {string} extend 扩展参数（通常是 JSON 字符串）
     * @return {string} 初始化结果
     */
    init(extend = '') {
        return '';
    }
    
    /**
     * 首页内容 - 获取分类列表
     * @param {boolean} filter 是否包含筛选条件
     * @return {object|string} 返回 {class: [...], filters: [...]}
     */
    homeContent(filter = false) {
        return '';
    }
    
    /**
     * 首页视频内容 - 获取推荐视频列表
     * @return {object|string} 返回 {list: [...]}
     */
    homeVideoContent() {
        return '';
    }
    
    /**
     * 分类内容 - 获取分类下的视频列表
     * @param {string} tid 分类ID
     * @param {string} pg 页码
     * @param {boolean} filter 是否启用筛选
     * @param {object} extend 筛选条件
     * @return {object|string} 返回 {list: [...], page: x, pagecount: x}
     */
    categoryContent(tid, pg, filter, extend) {
        return '';
    }
    
    /**
     * 详情内容 - 获取视频详情和播放列表
     * @param {Array} ids 视频ID数组
     * @return {object|string} 返回 {list: [视频详情]}
     */
    detailContent(ids) {
        return '';
    }
    
    /**
     * 搜索内容 - 搜索视频
     * @param {string} key 搜索关键词
     * @param {boolean} quick 是否快速搜索
     * @param {string} pg 页码
     * @return {object|string} 返回 {list: [...]}
     */
    searchContent(key, quick, pg = '1') {
        return '';
    }
    
    /**
     * 播放内容 - 获取播放地址
     * @param {string} flag 播放源标识
     * @param {string} id 视频ID或播放标识
     * @param {Array} vipFlags VIP标识列表
     * @return {object|string} 返回 {parse: 0/1, url: '...'}
     */
    playerContent(flag, id, vipFlags) {
        return '';
    }
    
    /**
     * 直播内容
     * @param {string} url 直播地址
     * @return {object|string} 直播内容
     */
    liveContent(url) {
        return '';
    }
    
    /**
     * 代理请求
     * @param {object} params 请求参数
     * @return {any} 代理响应
     */
    proxy(params) {
        return null;
    }
    
    /**
     * 自定义动作
     * @param {string} action 动作名称
     * @return {string} 动作结果
     */
    action(action) {
        return '';
    }
    
    /**
     * 销毁 - 清理资源
     */
    destroy() {
    }
    
    /**
     * 获取爬虫名称
     * @return {string} 爬虫名称
     */
    getName() {
        return '';
    }
    
    /**
     * 检查URL是否为视频格式
     * @param {string} url URL地址
     * @return {boolean} 是否为视频格式
     */
    isVideoFormat(url) {
        return true;
    }
    
    /**
     * 手动视频检查
     * @return {boolean} 检查结果
     */
    manualVideoCheck() {
        return false;
    }
    
    // ==================== 便捷方法 ====================
    
    /**
     * 发起 GET 请求
     * @param {string} url 请求地址
     * @param {object} params 查询参数
     * @param {object} headers 请求头
     * @param {number} timeout 超时时间（毫秒）
     * @param {boolean} verify 是否验证SSL证书
     * @param {boolean} allowRedirects 是否允许重定向
     * @return {Promise<object>} 响应对象
     */
    async fetch(url, params = null, headers = null, timeout = 5000, verify = true, allowRedirects = true) {
        try {
            const config = {
                timeout,
                headers: headers || {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                },
                params,
                httpsAgent: verify ? undefined : new (require('https').Agent)({ rejectUnauthorized: false }),
                maxRedirects: allowRedirects ? 10 : 0
            };
            
            const response = await axios.get(url, config);
            return response;
        } catch (error) {
            console.error(`Fetch error: ${error.message}`);
            throw error;
        }
    }
    
    /**
     * 发起 POST 请求
     * @param {string} url 请求地址
     * @param {object} params 查询参数
     * @param {object} data 请求体数据
     * @param {object} json JSON数据
     * @param {object} headers 请求头
     * @param {number} timeout 超时时间（毫秒）
     * @param {boolean} verify 是否验证SSL证书
     * @param {boolean} allowRedirects 是否允许重定向
     * @return {Promise<object>} 响应对象
     */
    async post(url, params = null, data = null, json = null, headers = null, timeout = 5000, verify = true, allowRedirects = true) {
        try {
            const config = {
                timeout,
                headers: headers || {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Content-Type': json ? 'application/json' : 'application/x-www-form-urlencoded'
                },
                params,
                httpsAgent: verify ? undefined : new (require('https').Agent)({ rejectUnauthorized: false }),
                maxRedirects: allowRedirects ? 10 : 0
            };
            
            if (json) {
                config.data = json;
            } else if (data) {
                config.data = data;
            }
            
            const response = await axios.post(url, config.data, config);
            return response;
        } catch (error) {
            console.error(`Post error: ${error.message}`);
            throw error;
        }
    }
    
    /**
     * 解析HTML内容
     * @param {string} content HTML内容
     * @return {object} cheerio对象
     */
    html(content) {
        return cheerio.load(content);
    }
    
    /**
     * 正则表达式匹配
     * @param {string} reg 正则表达式
     * @param {string} src 源字符串
     * @param {number} group 匹配组（默认1）
     * @return {string} 匹配结果
     */
    regStr(reg, src, group = 1) {
        const match = src.match(new RegExp(reg));
        return match ? match[group] || '' : '';
    }
    
    /**
     * 移除HTML标签
     * @param {string} src 源字符串
     * @return {string} 清理后的字符串
     */
    removeHtmlTags(src) {
        return src.replace(/<[^>]*>/g, '');
    }
    
    /**
     * 清理文本（移除表情符号等）
     * @param {string} src 源字符串
     * @return {string} 清理后的字符串
     */
    cleanText(src) {
        // 移除表情符号范围
        return src.replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F1E0}-\u{1F1FF}]/gu, '');
    }
    
    /**
     * JSON字符串转对象
     * @param {string} str JSON字符串
     * @return {object} JSON对象
     */
    str2json(str) {
        try {
            return JSON.parse(str);
        } catch (error) {
            console.error(`JSON parse error: ${error.message}`);
            return null;
        }
    }
    
    /**
     * 对象转JSON字符串
     * @param {object} obj 对象
     * @return {string} JSON字符串
     */
    json2str(obj) {
        return JSON.stringify(obj, null, 2);
    }
    
    /**
     * 日志输出
     * @param {any} msg 日志消息
     */
    log(msg) {
        if (typeof msg === 'object') {
            console.log(JSON.stringify(msg, null, 2));
        } else {
            console.log(msg);
        }
    }
}

// ==================== 结果构建器 ====================

/**
 * 结果构建器
 * 用于构建标准格式的返回结果
 */
class Result {
    
    /**
     * 构建分类结果
     * @param {Array} classes 分类列表 [{type_id:'', type_name:''}, ...]
     * @param {Array} vods 视频列表（可选）
     * @return {string} JSON 字符串
     */
    static classes(classes, vods = []) {
        return JSON.stringify({
            class: classes || [],
            list: vods || []
        });
    }
    
    /**
     * 构建列表结果
     * @param {Array} vods 视频列表
     * @param {number} page 当前页
     * @param {number} pagecount 总页数
     * @param {number} limit 每页数量
     * @param {number} total 总数量
     * @return {string} JSON 字符串
     */
    static list(vods, page = 1, pagecount = 1, limit = 20, total = 0) {
        return JSON.stringify({
            list: vods || [],
            page: page,
            pagecount: pagecount,
            limit: limit,
            total: total
        });
    }
    
    /**
     * 构建详情结果
     * @param {object} vod 视频详情
     * @return {string} JSON 字符串
     */
    static detail(vod) {
        return JSON.stringify({
            list: [vod]
        });
    }
    
    /**
     * 构建播放结果
     * @param {string} url 播放地址
     * @param {number} parse 是否需要解析（0=直接播放, 1=需要解析）
     * @param {object|null} header 请求头
     * @return {string} JSON 字符串
     */
    static player(url, parse = 0, header = null) {
        const result = {
            parse: parse,
            url: url
        };
        if (header) {
            result.header = header;
        }
        return JSON.stringify(result);
    }
    
    /**
     * 构建错误结果
     * @param {string} msg 错误信息
     * @return {string} JSON 字符串
     */
    static error(msg) {
        return JSON.stringify({ error: msg });
    }
}

// ==================== HTTP 请求工具类 ====================

/**
 * HTTP 请求工具类
 */
class Http {
    
    /**
     * 默认 User-Agent
     */
    static defaultUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
    
    /**
     * 发起 GET 请求
     * @param {string} url 请求地址
     * @param {object} headers 请求头
     * @param {number} timeout 超时时间（秒）
     * @return {Promise<string>} 响应内容
     */
    static async get(url, headers = {}, timeout = 30) {
        try {
            const config = {
                timeout: timeout * 1000,
                headers: {
                    'User-Agent': this.defaultUA,
                    ...headers
                },
                httpsAgent: new (require('https').Agent)({ rejectUnauthorized: false })
            };
            
            const response = await axios.get(url, config);
            return response.data;
        } catch (error) {
            console.error(`HTTP GET error: ${error.message}`);
            return '';
        }
    }
    
    /**
     * 发起 POST 请求
     * @param {string} url 请求地址
     * @param {any} data 请求数据（对象或字符串）
     * @param {object} headers 请求头
     * @param {number} timeout 超时时间（秒）
     * @return {Promise<string>} 响应内容
     */
    static async post(url, data = '', headers = {}, timeout = 30) {
        try {
            const config = {
                timeout: timeout * 1000,
                headers: {
                    'User-Agent': this.defaultUA,
                    'Content-Type': 'application/x-www-form-urlencoded',
                    ...headers
                },
                httpsAgent: new (require('https').Agent)({ rejectUnauthorized: false })
            };
            
            if (typeof data === 'object' && !Buffer.isBuffer(data)) {
                data = new URLSearchParams(data).toString();
            }
            
            const response = await axios.post(url, data, config);
            return response.data;
        } catch (error) {
            console.error(`HTTP POST error: ${error.message}`);
            return '';
        }
    }
    
    /**
     * 发起 POST JSON 请求
     * @param {string} url 请求地址
     * @param {any} data 请求数据
     * @param {object} headers 额外请求头
     * @param {number} timeout 超时时间（秒）
     * @return {Promise<string>} 响应内容
     */
    static async postJson(url, data, headers = {}, timeout = 30) {
        const jsonHeaders = {
            'Content-Type': 'application/json',
            ...headers
        };
        return this.post(url, JSON.stringify(data), jsonHeaders, timeout);
    }
}

// ==================== WebView 工具类 ====================

/**
 * WebView 工具类
 * 用于调用 WebView HTTP 服务获取网页内容
 * 
 * 使用示例：
 * 
 * // 基本使用
 * const result = await WebView.create('https://example.com').fetch();
 * 
 * // 链式调用设置参数
 * const result = await WebView.create('https://example.com')
 *     .silent(false)                    // 显示 WebView 弹窗
 *     .timeout(60000)                   // 设置超时 60 秒
 *     .headers({Referer: 'xxx'})        // 设置请求头
 *     .loadImages(false)                // 不加载图片
 *     .jsEnabled(true)                  // 启用 JavaScript
 *     .target('keyword')                // 等待关键字出现
 *     .fetch();
 * 
 * // 获取响应数据
 * const html = result.data.html;        // 页面 HTML（Base64 解码后）
 * const url = result.data.url;          // 最终 URL
 * const cookies = result.data.cookies;  // Cookies
 * const headers = result.data.request_headers; // 请求头
 * 
 * // 直接获取 HTML
 * const html = await WebView.create('https://example.com').getHtml();
 * 
 * // 获取 Cookies
 * const cookies = await WebView.create('https://example.com').getCookies();
 */
class WebView {
    
    /**
     * WebView 服务地址
     */
    static serviceUrl = 'http://127.0.0.1:2329/openWebView';
    
    /**
     * 构造函数（私有）
     * @param {string} url 要加载的网页地址
     */
    constructor(url) {
        this.params = {
            url: url,
            silent: 'true',  // 默认静默模式
            callback: 'json' // 默认 JSON 格式
        };
    }
    
    /**
     * 创建 WebView 实例
     * @param {string} url 要加载的网页地址
     * @return {WebView}
     */
    static create(url) {
        return new WebView(url);
    }
    
    /**
     * 设置 WebView 服务地址
     * @param {string} url 服务地址
     */
    static setServiceUrl(url) {
        WebView.serviceUrl = url;
    }
    
    /**
     * 设置静默模式
     * @param {boolean} silent 是否静默模式（不显示 WebView）
     * @return {WebView} 当前实例，支持链式调用
     */
    silent(silent = true) {
        this.params.silent = silent ? 'true' : 'false';
        return this;
    }
    
    /**
     * 设置超时时间
     * @param {number} timeout 超时时间（毫秒）
     * @return {WebView} 当前实例，支持链式调用
     */
    timeout(timeout) {
        this.params.timeout = timeout;
        return this;
    }
    
    /**
     * 设置请求头
     * @param {object} headers 请求头对象，例如 {Referer: 'xxx', 'User-Agent': 'xxx'}
     * @return {WebView} 当前实例，支持链式调用
     */
    headers(headers) {
        // 将请求头转换为 JSON 格式
        this.params.headers = JSON.stringify(headers);
        return this;
    }
    
    /**
     * 设置是否加载图片
     * @param {boolean} loadImages 是否加载图片
     * @return {WebView} 当前实例，支持链式调用
     */
    loadImages(loadImages = true) {
        this.params.loadImages = loadImages ? 'true' : 'false';
        return this;
    }
    
    /**
     * 设置是否启用 JavaScript
     * @param {boolean} jsEnabled 是否启用 JavaScript
     * @return {WebView} 当前实例，支持链式调用
     */
    jsEnabled(jsEnabled = true) {
        this.params.jsEnabled = jsEnabled ? 'true' : 'false';
        return this;
    }
    
    /**
     * 设置返回格式
     * @param {string} callback 返回格式：json（默认）、html、text
     * @return {WebView} 当前实例，支持链式调用
     */
    callback(callback) {
        this.params.callback = callback;
        return this;
    }
    
    /**
     * 设置目标关键字（等待关键字出现）
     * @param {string} target 目标关键字，设置后忽略 timeout，持续查找直到找到关键字或用户关闭弹窗
     * @return {WebView} 当前实例，支持链式调用
     */
    target(target) {
        this.params.target = target;
        return this;
    }
    
    /**
     * 发起请求并获取响应
     * @return {Promise<object|null>} 返回响应数据，格式：
     * {
     *   code: 0,                    // 0 成功，其他失败
     *   message: 'ok',              // 状态消息
     *   data: {
     *     html: '...',              // 页面 HTML（Base64 编码）
     *     url: '...',               // 最终 URL
     *     title: '...',             // 页面标题
     *     cookies: '...',           // Cookies
     *     request_headers: [...]    // 请求头
     *   }
     * }
     * 如果 callback 设置为 html 或 text，则直接返回 HTML 或文本内容
     */
    async fetch() {
        // 构建请求 URL
        const url = WebView.serviceUrl + '?' + new URLSearchParams(this.params).toString();
        
        try {
            // 发起请求
            const response = await Http.get(url, {}, 120); // 默认 120 秒超时
            
            if (!response) {
                return null;
            }
            
            // 如果是 JSON 格式，解析响应
            if (this.params.callback === 'json') {
                const data = JSON.parse(response);
                
                // 解码 HTML（从 Base64）
                if (data.data && data.data.html) {
                    data.data.html = Buffer.from(data.data.html, 'base64').toString('utf-8');
                }
                
                return data;
            }
            
            // 否则直接返回响应内容（HTML 或文本）
            return response;
        } catch (error) {
            console.error(`WebView fetch error: ${error.message}`);
            return null;
        }
    }
    
    /**
     * 获取页面 HTML
     * @return {Promise<string|null>} 页面 HTML 内容
     */
    async getHtml() {
        const result = await this.fetch();
        
        if (result && typeof result === 'object' && result.data && result.data.html) {
            return result.data.html;
        }
        
        if (typeof result === 'string') {
            return result;
        }
        
        return null;
    }
    
    /**
     * 获取 Cookies
     * @return {Promise<string|null>} Cookies 字符串
     */
    async getCookies() {
        const result = await this.fetch();
        
        if (result && typeof result === 'object' && result.data && result.data.cookies) {
            return result.data.cookies;
        }
        
        return null;
    }
    
    /**
     * 获取最终 URL
     * @return {Promise<string|null>} 最终 URL
     */
    async getUrl() {
        const result = await this.fetch();
        
        if (result && typeof result === 'object' && result.data && result.data.url) {
            return result.data.url;
        }
        
        return null;
    }
    
    /**
     * 获取请求头
     * @return {Promise<object|null>} 请求头对象
     */
    async getRequestHeaders() {
        const result = await this.fetch();
        
        if (result && typeof result === 'object' && result.data && result.data.request_headers) {
            return result.data.request_headers;
        }
        
        return null;
    }
    
    /**
     * 检查是否成功
     * @return {Promise<boolean>} 是否成功
     */
    async isSuccess() {
        const result = await this.fetch();
        
        if (result && typeof result === 'object' && result.code !== undefined) {
            return result.code === 0;
        }
        
        return false;
    }
}

module.exports = {
    Spider,
    Result,
    Http,
    WebView
};
