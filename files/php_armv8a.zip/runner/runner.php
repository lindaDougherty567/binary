<?php
/**
 * PHP Runner 入口脚本
 * 用于加载并执行用户的爬虫脚本
 * 
 * 用法: php runner.php <爬虫脚本路径> <方法名> <argsJson>
 * 示例: php runner.php /path/to/spider.php homeContent '{"filter":true}'
 */

// ==================== 错误处理配置 ====================

error_reporting(E_ALL);
ini_set('display_errors', 1);

/**
 * 注册 shutdown 函数，捕获致命错误
 */
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        echo json_encode([
            'error' => "{$error['message']} in {$error['file']}:{$error['line']}"
        ], JSON_UNESCAPED_UNICODE);
    }
});

// ==================== 加载基类 ====================

require_once __DIR__ . '/Spider.php';

// ==================== 参数解析 ====================

if ($argc < 4) {
    echo Result::error('Usage: php runner.php <spider> <method> <argsJson>');
    exit(1);
}

$spiderPath = $argv[1];  // 爬虫脚本路径
$method = $argv[2];       // 方法名
$argsJson = $argv[3];     // JSON 参数

// 解析 JSON 参数
$params = json_decode($argsJson, true) ?: [];

// ==================== 加载爬虫脚本 ====================

if (!file_exists($spiderPath)) {
    echo Result::error("Spider not found: $spiderPath");
    exit(1);
}

require_once $spiderPath;

// 使用 class_alias 将插件的 Spider 类映射为 PluginSpider
// 这样可以避免与基类 BaseSpider 冲突
if (class_exists('Spider')) {
    class_alias('Spider', 'PluginSpider');
} else {
    echo Result::error('Spider class not found in plugin');
    exit(1);
}

// ==================== 实例化并调用方法 ====================

$spider = new PluginSpider();

try {
    // 检查方法是否存在
    if (!method_exists($spider, $method)) {
        $result = Result::error("Unknown method: $method");
    } else {
        // 根据方法名调用对应方法
        switch ($method) {
            case 'init':
                $result = $spider->init($params['ext'] ?? '');
                break;
            case 'homeContent':
                $result = $spider->homeContent($params['filter'] ?? false);
                break;
            case 'homeVideoContent':
                $result = $spider->homeVideoContent();
                break;
            case 'categoryContent':
                $result = $spider->categoryContent(
                    $params['tid'] ?? '',
                    $params['pg'] ?? '1',
                    $params['filter'] ?? false,
                    $params['extend'] ?? []
                );
                break;
            case 'detailContent':
                $result = $spider->detailContent($params['ids'] ?? []);
                break;
            case 'searchContent':
                $result = $spider->searchContent(
                    $params['key'] ?? '',
                    $params['quick'] ?? false,
                    $params['pg'] ?? '1'
                );
                break;
            case 'playerContent':
                $result = $spider->playerContent(
                    $params['flag'] ?? '',
                    $params['id'] ?? '',
                    $params['vipFlags'] ?? []
                );
                break;
            case 'liveContent':
                $result = $spider->liveContent($params['url'] ?? '');
                break;
            case 'proxy':
                $result = $spider->proxy($params);
                break;
            case 'action':
                $result = $spider->action($params['action'] ?? '');
                break;
            case 'destroy':
                $spider->destroy();
                $result = '';
                break;
            default:
                $result = Result::error("Unknown method: $method");
        }
    }
} catch (Throwable $e) {
    $result = Result::error($e->getMessage());
}

// ==================== 输出结果 ====================

if (is_string($result)) {
    echo $result;
} else {
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
}
