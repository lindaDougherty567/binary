<?php
/**
 * PHP Spider 基类和工具类
 * 
 * 包含：
 * - BaseSpider: 爬虫基类，所有爬虫脚本应继承此类
 * - Result: 结果构建器，用于构建标准格式的返回结果
 * - Http: HTTP 请求工具类
 * - Crypto: 加解密工具类
 */

// ==================== 爬虫基类 ====================

/**
 * 爬虫基类
 * 所有 PHP 爬虫脚本应继承此类并实现相应方法
 */
class BaseSpider {
    
    public $siteKey = '';   // 站点标识
    public $siteType = 0;   // 站点类型
    
    /**
     * 初始化
     * @param string $extend 扩展参数（通常是 JSON 字符串）
     * @return string 初始化结果
     */
    public function init($extend = '') {
        return '';
    }
    
    /**
     * 首页内容 - 获取分类列表
     * @param bool $filter 是否包含筛选条件
     * @return array|string 返回 ['class' => [...], 'filters' => [...]]
     */
    public function homeContent($filter = false) {
        return '';
    }
    
    /**
     * 首页视频内容 - 获取推荐视频列表
     * @return array|string 返回 ['list' => [...]]
     */
    public function homeVideoContent() {
        return '';
    }
    
    /**
     * 分类内容 - 获取分类下的视频列表
     * @param string $tid 分类ID
     * @param string $pg 页码
     * @param bool $filter 是否启用筛选
     * @param array $extend 筛选条件
     * @return array|string 返回 ['list' => [...], 'page' => x, 'pagecount' => x]
     */
    public function categoryContent($tid, $pg, $filter, $extend) {
        return '';
    }
    
    /**
     * 详情内容 - 获取视频详情和播放列表
     * @param array $ids 视频ID数组
     * @return array|string 返回 ['list' => [视频详情]]
     */
    public function detailContent($ids) {
        return '';
    }
    
    /**
     * 搜索内容 - 搜索视频
     * @param string $key 搜索关键词
     * @param bool $quick 是否快速搜索
     * @param string $pg 页码
     * @return array|string 返回 ['list' => [...]]
     */
    public function searchContent($key, $quick, $pg = '1') {
        return '';
    }
    
    /**
     * 播放内容 - 获取播放地址
     * @param string $flag 播放源标识
     * @param string $id 视频ID或播放标识
     * @param array $vipFlags VIP标识列表
     * @return array|string 返回 ['parse' => 0/1, 'url' => '...']
     */
    public function playerContent($flag, $id, $vipFlags) {
        return '';
    }
    
    /**
     * 直播内容
     * @param string $url 直播地址
     * @return array|string 直播内容
     */
    public function liveContent($url) {
        return '';
    }
    
    /**
     * 代理请求
     * @param array $params 请求参数
     * @return mixed 代理响应
     */
    public function proxy($params) {
        return null;
    }
    
    /**
     * 自定义动作
     * @param string $action 动作名称
     * @return string 动作结果
     */
    public function action($action) {
        return '';
    }
    
    /**
     * 销毁 - 清理资源
     */
    public function destroy() {
    }
    
    // ==================== 便捷方法 ====================
    
    /**
     * 发起 GET 请求
     * @param string $url 请求地址
     * @param array $headers 请求头
     * @return string 响应内容
     */
    protected function fetch($url, $headers = []) {
        return Http::get($url, $headers);
    }
    
    /**
     * 发起 POST 请求
     * @param string $url 请求地址
     * @param mixed $data 请求数据
     * @param array $headers 请求头
     * @return string 响应内容
     */
    protected function post($url, $data = '', $headers = []) {
        return Http::post($url, $data, $headers);
    }
    
    /**
     * 解析 JSON
     * @param string $json JSON 字符串
     * @return array|null 解析结果
     */
    protected function jsonDecode($json) {
        return json_decode($json, true);
    }
    
    /**
     * 编码为 JSON
     * @param mixed $data 数据
     * @return string JSON 字符串
     */
    protected function jsonEncode($data) {
        return json_encode($data, JSON_UNESCAPED_UNICODE);
    }
}

// ==================== 结果构建器 ====================

/**
 * 结果构建器
 * 用于构建标准格式的返回结果
 */
class Result {
    
    /**
     * 构建分类结果
     * @param array $classes 分类列表 [['type_id'=>'', 'type_name'=>''], ...]
     * @param array $vods 视频列表（可选）
     * @return string JSON 字符串
     */
    public static function classes($classes, $vods = []) {
        return json_encode([
            'class' => $classes ?: [],
            'list' => $vods ?: []
        ], JSON_UNESCAPED_UNICODE);
    }
    
    /**
     * 构建列表结果
     * @param array $vods 视频列表
     * @param int $page 当前页
     * @param int $pagecount 总页数
     * @param int $limit 每页数量
     * @param int $total 总数量
     * @return string JSON 字符串
     */
    public static function list($vods, $page = 1, $pagecount = 1, $limit = 20, $total = 0) {
        return json_encode([
            'list' => $vods ?: [],
            'page' => $page,
            'pagecount' => $pagecount,
            'limit' => $limit,
            'total' => $total
        ], JSON_UNESCAPED_UNICODE);
    }
    
    /**
     * 构建详情结果
     * @param array $vod 视频详情
     * @return string JSON 字符串
     */
    public static function detail($vod) {
        return json_encode([
            'list' => [$vod]
        ], JSON_UNESCAPED_UNICODE);
    }
    
    /**
     * 构建播放结果
     * @param string $url 播放地址
     * @param int $parse 是否需要解析（0=直接播放, 1=需要解析）
     * @param array|null $header 请求头
     * @return string JSON 字符串
     */
    public static function player($url, $parse = 0, $header = null) {
        $result = [
            'parse' => $parse,
            'url' => $url
        ];
        if ($header) {
            $result['header'] = $header;
        }
        return json_encode($result, JSON_UNESCAPED_UNICODE);
    }
    
    /**
     * 构建错误结果
     * @param string $msg 错误信息
     * @return string JSON 字符串
     */
    public static function error($msg) {
        return json_encode(['error' => $msg], JSON_UNESCAPED_UNICODE);
    }
}

// ==================== HTTP 请求工具类 ====================

/**
 * HTTP 请求工具类
 */
class Http {
    
    /**
     * 默认 User-Agent
     */
    private static $defaultUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
    
    /**
     * 发起 GET 请求
     * @param string $url 请求地址
     * @param array $headers 请求头（数组格式：['Header: Value', ...]）
     * @param int $timeout 超时时间（秒）
     * @return string 响应内容
     */
    public static function get($url, $headers = [], $timeout = 30) {
        $ch = curl_init();
        
        // 设置 URL
        curl_setopt($ch, CURLOPT_URL, $url);
        
        // 返回响应内容
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        // 设置请求头
        if (empty($headers)) {
            $headers = ['User-Agent: ' . self::$defaultUA];
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        
        // 禁用 SSL 验证
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        
        // 设置超时
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        
        // 跟随重定向
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        
        // 执行请求
        $response = curl_exec($ch);
        curl_close($ch);
        
        return $response ?: '';
    }
    
    /**
     * 发起 POST 请求
     * @param string $url 请求地址
     * @param mixed $data 请求数据（数组或字符串）
     * @param array $headers 请求头
     * @param int $timeout 超时时间（秒）
     * @return string 响应内容
     */
    public static function post($url, $data = '', $headers = [], $timeout = 30) {
        $ch = curl_init();
        
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        
        // 处理请求数据
        if (is_array($data)) {
            $data = http_build_query($data);
        }
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        
        // 设置请求头
        if (empty($headers)) {
            $headers = [
                'User-Agent: ' . self::$defaultUA,
                'Content-Type: application/x-www-form-urlencoded'
            ];
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        
        // 禁用 SSL 验证
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        return $response ?: '';
    }
    
    /**
     * 发起 POST JSON 请求
     * @param string $url 请求地址
     * @param mixed $data 请求数据
     * @param array $headers 额外请求头
     * @param int $timeout 超时时间（秒）
     * @return string 响应内容
     */
    public static function postJson($url, $data, $headers = [], $timeout = 30) {
        $headers[] = 'Content-Type: application/json';
        return self::post($url, json_encode($data), $headers, $timeout);
    }
}

// ==================== 加解密工具类 ====================

/**
 * 加解密工具类
 */
class Crypto {
    
    /**
     * MD5 加密
     * @param string $data 原始数据
     * @return string MD5 哈希值
     */
    public static function md5($data) {
        return md5($data);
    }
    
    /**
     * Base64 编码
     * @param string $data 原始数据
     * @return string Base64 编码字符串
     */
    public static function base64Encode($data) {
        return base64_encode($data);
    }
    
    /**
     * Base64 解码
     * @param string $data Base64 编码字符串
     * @return string 解码后的数据
     */
    public static function base64Decode($data) {
        return base64_decode($data);
    }
    
    /**
     * URL 编码
     * @param string $data 原始数据
     * @return string URL 编码字符串
     */
    public static function urlEncode($data) {
        return urlencode($data);
    }
    
    /**
     * URL 解码
     * @param string $data URL 编码字符串
     * @return string 解码后的数据
     */
    public static function urlDecode($data) {
        return urldecode($data);
    }
}
